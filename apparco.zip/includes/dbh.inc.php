<?php

$dbHost = "50.62.209.111:3306";
$dbUser = "pedro";
$dbPass = "xaTk04@6";
$dbBanco = "arco";

$conn = mysqli_connect($dbHost, $dbUser, $dbPass, $dbBanco);
